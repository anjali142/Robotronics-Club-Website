LIBRERIAS
=========

Copiar carpeta "lib" a la carpeta "libreries" de Arduino.
